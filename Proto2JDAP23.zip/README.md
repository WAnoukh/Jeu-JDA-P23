# Jeu JDA P23
 Jeu pour la JDA P23 d'Arcadia

### Compilation
Pour compiler le programme python éxécutez la commande suivante : 
```bash
pyinstaller -F votrepath/main.py
```
/!\ Ne pas faire dans le dossier du git !

### Contrôles

* Déplacement horizontal : KEY_LEFT - KEY_RIGHT
* Saut : KEY_UP
* Réinitialiser le jeu : R
* Lancer une nouvelle génération avec les blocks qui font des trucs stylés : Espace